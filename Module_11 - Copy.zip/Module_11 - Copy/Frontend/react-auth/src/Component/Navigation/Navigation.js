import React from 'react';
import {NavLink} from 'react-router-dom'
import './Navigation.css'
const Navigation = () => {
    return (
        <div className='nav-container'>
            <ul>
                <li><NavLink to={"/register"} className={"nav-item"}>Register</NavLink></li>
                <li><NavLink to={"/login"} className={"nav-item"}>Login</NavLink></li>
                <li><NavLink to={"/profile"} className={"nav-item"}>Profile</NavLink></li>
            </ul>
        </div>
    );
};

export default Navigation;