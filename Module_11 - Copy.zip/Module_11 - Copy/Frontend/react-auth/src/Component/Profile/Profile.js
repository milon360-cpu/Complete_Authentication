import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
    const navigate = useNavigate();
    
    
    useEffect(()=>
    {
        const token = localStorage.getItem("token");
        if(!token)
        {
            navigate("/login");
            return ;
        }
        fetch("http://localhost:5000/profile",
        {
            method : "GET",
            headers:
            {
                "Content-Type":"application/json",
                Authorization : token
            }
        })
        .then((response)=> response.json())
        .then((data)=>
        {
            if(data.success)
            {
                console.log(data);
            }
            else 
            {
                navigate("/login");
            }
        })
        .catch((err)=>
        {
            console.log(err);
        })
     
    },[])
   
    return (
        <div>
            <h1>Profile</h1>
            <button className='btn btn-warning' onClick={()=>
            {
                localStorage.removeItem("token");
                navigate("/login");
            }}>logout</button>
        </div>
    );
};

export default Profile;