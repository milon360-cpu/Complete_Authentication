import React, { useState,useEffect } from 'react';
import {useNavigate } from "react-router-dom"
import './Register.css'
const Register = () => {
    const [userData,setUserData] = useState({email:"", password:""});
    const navigate = useNavigate()


     // check authentication 
     const token = localStorage.getItem("token");
     useEffect(()=>
     {
         fetch("http://localhost:5000/profile",
         {
             method : "GET",
             headers:
             {
                 "Content-Type":"application/json",
                 Authorization : token
             }
         })
         .then((response)=> response.json())
         .then((data)=>
         {
             if(data.success)
             {
                 navigate("/profile")
             }
             else 
             {
                 navigate("/login");
             }
         })
         .catch((err)=>
         {
             console.log(err);
         })
      
     },[])






    const handelChange = (e)=>
    {
        setUserData({...userData,[e.target.name]:e.target.value});
    }

    const handelSubmit = (e)=>
    {
        e.preventDefault();
         fetch("http://localhost:5000/create/single/user",
         {
            method: "POST",
            headers: {"Content-Type":"application/json"},
            body : JSON.stringify(userData)
         })
         .then((response)=>
         {
            if(response.ok)
            {
                return navigate("/login");
            }
            else 
            {
                return response.json()
            }
         })
         .then((data)=> console.log(data))
    }
    return (
        <div className='register-container'>
            <form onSubmit={handelSubmit}>
                <h1>Register</h1>
                <hr />
                <div className="form-group mt-5">
                    <label htmlFor="">Email</label>
                    <input type="email"  className='form-control mt-2' placeholder='@gmail.com' value={userData.email} onChange={handelChange} name='email' required/>
                </div>
                <div className="form-group mt-4">
                    <label htmlFor="">Password</label>
                    <input type="password"  className='form-control mt-2' placeholder='password' value={userData.password} onChange={handelChange} name='password' required/>
                </div>
                <button type='submit' className='btn btn-primary mt-4'>Register</button>
            </form>
        </div>
    );
};

export default Register;