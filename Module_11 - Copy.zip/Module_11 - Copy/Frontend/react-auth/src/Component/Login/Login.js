import React, { useState,useEffect } from 'react';
import './Login.css'
import {useNavigate} from 'react-router-dom';
const Login = () => {
    const navigate = useNavigate();


    // check authentication 
    const token = localStorage.getItem("token");
    useEffect(()=>
    {
        fetch("http://localhost:5000/profile",
        {
            method : "GET",
            headers:
            {
                "Content-Type":"application/json",
                Authorization : token
            }
        })
        .then((response)=> response.json())
        .then((data)=>
        {
            if(data.success)
            {
                navigate("/profile")
            }
            else 
            {
                navigate("/login");
            }
        })
        .catch((err)=>
        {
            console.log(err);
        })
     
    },[])

    const [loginUserData,setLoginUserData] = useState({ email:'', password:'' });
    const handelChange = (e)=>
    {
        setLoginUserData({...loginUserData,[e.target.name]:e.target.value});
    }
    const handelSubmit = (e)=>
    {
        e.preventDefault();
        fetch("http://localhost:5000/login/user",
        {
            method:"POST",
            headers: {"Content-Type":"application/json"},
            body : JSON.stringify(loginUserData)
        })
        .then((response)=>response.json())  
        .then((data)=> 
        {
            if(data.success)
            {
                navigate("/profile");
                localStorage.setItem("token",data.data.token);
            }
        })
    }
    return (
    <div className='login-container'>
            <form onSubmit={handelSubmit}>
                <h1>Login</h1>
                <hr />
                <div className="from-group mt-5">
                    <label htmlFor="">Email</label>
                    <input type="email"  className='form-control mt-2' name='email' placeholder='@gmail.com' onChange={handelChange}/>
                </div>
                <div className="from-group mt-4">
                    <label htmlFor="">Password</label>
                    <input type="password"  className='form-control mt-2' name='password' placeholder='password' onChange={handelChange}/>
                </div>
                <button type='submit' className='btn btn-primary mt-4'>Login</button>
            </form>
    </div>
    );
};

export default Login;