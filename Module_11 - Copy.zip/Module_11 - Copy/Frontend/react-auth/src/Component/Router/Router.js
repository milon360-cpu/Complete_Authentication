import React from 'react';
import {BrowserRouter,Routes,Route} from "react-router-dom";
import Navigation from '../Navigation/Navigation';
import Register from '../Register/RegisTer';
import Login from './../Login/Login';
import Profile from '../Profile/Profile';
const Router = () => {
    return (
        <>
            <BrowserRouter>
                <Navigation />
                <Routes>
                    <Route path='/register' element = {<Register />}></Route>
                    <Route path='/login' element = {<Login />}></Route>
                    <Route path='/profile' element = {<Profile />}></Route>
                </Routes>
            </BrowserRouter>
        </>
    );
};

export default Router;